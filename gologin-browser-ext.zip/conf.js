const CONF = {
  url: 'http://127.0.0.1:36912/'
}

