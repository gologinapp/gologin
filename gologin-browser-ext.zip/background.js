'use strict';

let openUrl = null;
let UID = null;

const debounceSavingCookies = debounce(storeCookies, 3000);

chrome.cookies.onChanged.addListener(() => {
  debounceSavingCookies();
});

chrome.windows.onRemoved.addListener(() => {
  storeCookies();
});

// Подсчет вкладок, т.к. при закрытии браузера на Mac он сворачивается
// Если вкладок 0 (вкладки обнуляются при закрытии) шлём сигнал на принудительное завершение
chrome.tabs.onRemoved.addListener(tab => {
  chrome.tabs.query({}, tabs => {
    if (tabs.length === 0) {
      storeCookies(() => {
        fetch(`${CONF.url}close/${UID}`);
      });
    }
  });
});

function debounce(func, time) {
  let timeout;
  return function() {
    clearTimeout(timeout);
    timeout = setTimeout(() => func(), time);
  };
}

function closeBrowser() {
  logInfo('Closing browser...');

  chrome.windows.getAll({}, function(windowArray) {
    for (var i = 0; i < windowArray.length; i++) {
      var window = windowArray[i];
      chrome.windows.remove(window.id);
    }
  });

  chrome.processes.getProcessInfo([], false, function(processes) {
    for (var i = 0; i < processes.length; i++) {
      var process = processes[i];
      if (process.type === 'browser') {
        try {
          chrome.processes.terminate(process.id);
        } catch (e) {
          console.error(e);
        }
      }
    }
  });
}

function storeCookies(successCallback) {
  chrome.cookies.getAll({}, cookies => {
    if (cookies.length) {
      let cookiesBody = cookies.map(
        ({ domain, name, value, hostOnly, path, secure, httpOnly, session, expirationDate = 0 }) => {
          let domainWithoutDot = domain;
          if (domain.startsWith('.')) {
            domainWithoutDot = domain.substr(1);
          }
          const url = 'http' + (secure ? 's' : '') + '://' + domainWithoutDot + path;

          return { url, domain, name, value, hostOnly, path, secure, httpOnly, session, expirationDate };
        }
      );

      logInfo('Saving cookies...');
      fetch(`${CONF.url}cookies/${UID}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(cookiesBody),
      })
        .then(() => successCallback && successCallback())
        .catch(error => {
          const message = 'Failed to save data. Please try again later.';
          logError(`${message}: ${error.message}`);
          alert(`${message}`);
        });
    }
  });
}

function start(data) {
  setInterval(bptimer, 5000);

  if (data && Array.isArray(data)) {
    for (let cookie of data) {
      delete cookie.browserType;
      delete cookie.storeId;
      delete cookie.hostOnly;
      if (cookie.session) {
        delete cookie.expirationDate;
      }
      delete cookie.session;

      if (cookie.name.startsWith("__Host-")) {
        delete cookie.domain;
      }

      chrome.cookies.set(cookie, cookie => {
        if (chrome.runtime.lastError) {
          logError("Cannot set cookie." + chrome.runtime.lastError.message);  
        }
      });
    }
  }

  sesssionReady();
}

function sesssionReady() {
  fetch(`${CONF.url}session/ready`).then(response => {
    var message = 'Everything is ready.';
    logInfo(message);
  });
}

function bptimer() {
  return fetch(`${CONF.url}timer/update/${UID}`);
}

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.mlaLog) {
    if (request.level == 'error') {
      logError(request.message);
    } else {
      logInfo(request.message);
    }
  }
});

function logError(msg) {
  console.error(msg);
}

function logInfo(msg) {
  console.log(msg);
}

async function init() {
  const uidFilePath = await chrome.runtime.getURL('uid.json');

  try {
    const uidConf = await fetch(uidFilePath).then(response => response.json());
    UID = uidConf.uid;
  } catch (error) {
    logError(`Can't get configuration file: ${error.message}`);
  }

  if (UID) {
    return fetch(`${CONF.url}cookies/${UID}`, { method: 'GET' })
      .then(response => response.json())
      .then(data => start(data))
      .catch(error => {
        const message = 'Failed to load data';
        logError(`${message}: ${error.message}`);
      });
  }

  logError('UID is empty');
}

init();
